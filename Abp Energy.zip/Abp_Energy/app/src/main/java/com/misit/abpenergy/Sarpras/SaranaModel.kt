package com.misit.abpenergy.Sarpras

class SaranaModel(val id:Long,val noPol:String,val noLV:String)