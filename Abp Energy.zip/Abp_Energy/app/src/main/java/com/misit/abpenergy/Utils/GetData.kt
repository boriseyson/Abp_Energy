package com.misit.abpenergy.Utils

class GetData {
    var data =false
    get() = field
    set(value) { field=value}
}