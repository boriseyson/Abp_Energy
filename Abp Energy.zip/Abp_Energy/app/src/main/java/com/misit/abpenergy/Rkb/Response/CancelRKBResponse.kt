package com.misit.abpenergy.Rkb.Response

import com.google.gson.annotations.SerializedName

data class CancelRKBResponse(

    @field:SerializedName("success")
    val success: Boolean? = null
)