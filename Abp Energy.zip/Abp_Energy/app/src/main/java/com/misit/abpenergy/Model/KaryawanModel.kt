package com.misit.abpenergy.Model

class KaryawanModel(val id:Long,val nik:String,val nama:String,val jabatan:String)