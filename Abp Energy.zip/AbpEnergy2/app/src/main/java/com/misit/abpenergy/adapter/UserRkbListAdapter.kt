package com.misit.abpenergy.adapter

import android.content.Context
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.misit.abpenergy.R
import com.misit.abpenergy.response.DataItem
import org.joda.time.DateTime
import org.joda.time.LocalDate
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.util.*


class UserRkbListAdapter(
    private val context: Context?,
    private val rkbList:MutableList<DataItem>):
    RecyclerView.Adapter<UserRkbListAdapter.MyViewHolder>(){


    private val layoutInflater: LayoutInflater
    private var simpleDateFormat: SimpleDateFormat? = null

    private var onItemClickListener: OnItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): UserRkbListAdapter.MyViewHolder {

        val view = layoutInflater.inflate(R.layout.list_item_rkb,parent,false)
        return UserRkbListAdapter.MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return rkbList.size
    }

    override fun onBindViewHolder(holder: UserRkbListAdapter.MyViewHolder, position: Int) {
        val today = Date()
        var rkbList =rkbList[position]
        val date = LocalDate.parse(rkbList.tglOrder)
        val fmt: DateTimeFormatter = DateTimeFormat.forPattern("d MMMM, yyyy")

        val kabagAppr = rkbList.tglDisetujui?.split(" ")
        val KttAppr = rkbList.tglDiketahui?.split(" ")
        var tglOrder = date.toString(fmt);
        holder.tvNorkb?.text = rkbList.noRkb
        holder.tvTgl?.text =tglOrder.toString()
        holder.tvUserCreate?.text = rkbList.namaLengkap
        holder.tvDeptSect?.text = "${rkbList.dept} - ${rkbList.section}"
        holder.tvKabag.text = if(rkbList.disetujui=="1") {
            kabagAppr!![1]+", "+LocalDate.parse(kabagAppr!![0]).toString(fmt)
                                }else{"Waiting"}
        if(rkbList.disetujui=="1"){
            holder.tvKabag.setTextSize(TypedValue.COMPLEX_UNIT_SP,8F)
            holder.tvKabag.setBackgroundResource(R.drawable.btn_success)
        }else{
            holder.tvKabag.setBackgroundResource(R.drawable.btn_waiting)
        }
        holder.tvKtt.text = if(rkbList.diketahui=="1") {
                             KttAppr!![1]+", "+LocalDate.parse(KttAppr!![0]).toString(fmt)
                             }else{"Waiting"}
        if(rkbList.diketahui=="1"){
            holder.tvKtt.setBackgroundResource(R.drawable.btn_success)
        }else{
            holder.tvKtt.setBackgroundResource(R.drawable.btn_waiting)
        }
        if(rkbList.disetujui=="1" && rkbList.diketahui=="1"){
            holder.tvNorkb.setBackgroundResource(R.color.bgApprove)
        }else{
            holder.tvNorkb.setBackgroundResource(R.color.bgWaiting)
        }
        if(onItemClickListener != null){
            holder.cvRkb?.setOnClickListener{onItemClickListener?.onItemClick(rkbList.noRkb)}
        }
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var cvRkb = itemView.findViewById<View>(R.id.cv_Rkb) as CardView
        var tvNorkb = itemView.findViewById<View>(R.id.tv_norkb) as TextView
        var tvTgl= itemView.findViewById<View>(R.id.tv_tgl) as TextView
        var tvUserCreate = itemView.findViewById<View>(R.id.tv_userCreate) as TextView
        var tvDeptSect = itemView.findViewById<View>(R.id.tv_dept_sect) as TextView
        var tvKabag = itemView.findViewById<View>(R.id.tv_kabag) as TextView
        var tvKtt = itemView.findViewById<View>(R.id.tv_ktt) as TextView
    }
    interface OnItemClickListener{
        fun onItemClick(noRkb:String?)
    }
    fun setListener (listener:OnItemClickListener){
        onItemClickListener = listener
    }
    init {
        layoutInflater = LayoutInflater.from(context)
        simpleDateFormat= SimpleDateFormat("yyyy-MM-dd")
    }

}