package com.misit.abpenergy.api

import com.misit.abpenergy.response.CsrfTokenResponse
import com.misit.abpenergy.response.RkbResponse
import com.misit.abpenergy.response.UserResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiEndPoint{
    @GET("neardeal/get/json")
    fun getToken(@Query("csrf_token") tokenId:String): Call<CsrfTokenResponse>?
    @FormUrlEncoded
    @POST("api/android/login/validate")
    fun loginChecklogin(@Field("username") username:String?,
                        @Field("password") password:String?,
                        @Field("_token") csrf_token:String?): Call<UserResponse>

    @GET("api/android/get/rkb/user")
    fun getRkbUser(@Query("username") username:String ,
                   @Query("department") department:String,
                   @Query("close_rkb") close_rkb:String?,
                   @Query("search") search:String?,
                   @Query("disetujui") disetujui:String?,
                   @Query("diketahui") diketahui:String?,
                   @Query("approve") approve:String?,
                   @Query("cancel") cancel:String?,
                   @Query("page") page:String?,
                   @Query("level") level:String?)
    : Call<RkbResponse>?
    @GET("/v3/rkb")
    fun getRkbKabag(@Query("android") tokenId:String): Call<RkbResponse>?
    @GET("/v3/rkb")
    fun getRkbKtt(@Query("android") tokenId:String): Call<RkbResponse>?
}