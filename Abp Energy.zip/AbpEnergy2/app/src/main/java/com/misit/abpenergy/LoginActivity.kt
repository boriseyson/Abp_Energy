package com.misit.abpenergy

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import com.misit.abpenergy.api.ApiClient
import com.misit.abpenergy.api.ApiEndPoint
import com.misit.abpenergy.response.CsrfTokenResponse
import com.misit.abpenergy.response.UserResponse
import com.misit.abpenergy.utils.ConnectivityUtil
import com.misit.abpenergy.utils.PopupUtil
import com.misit.abpenergy.utils.PrefsUtil
import es.dmoral.toasty.Toasty
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity(),View.OnClickListener
 {

    private var csrf_token : String?=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        PrefsUtil.initInstance(this)
//        getToken()
        loginBtn.setOnClickListener(this)
        InPassword.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                //Perform Code

                if(isValidatedAll()) {
                    loginSubmit(
                        InUsername.text.toString().trim(),
                        InPassword.text.toString().trim()
                    )
                }
                return@OnKeyListener true
            }
            false
        })
    }

    override fun onClick(v: View?) {
        if(v?.id==R.id.loginBtn){
            if(isValidatedAll()){
                loginSubmit(InUsername.text.toString().trim(),InPassword.text.toString().trim())
            }

        }
    }
    override fun onResume() {
        if(cekKoneksi(this)){
            getToken()
        }else{
            Toasty.error(this, "KONEKSI TIDAK ADA", Toasty.LENGTH_SHORT).show()
        }

        super.onResume()
    }
    fun cekKoneksi(context: Context):Boolean{
        var koneksiStatus : Boolean = true
        val connectivityManager= context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo

        return networkInfo != null && networkInfo.isConnected
    }
    private fun getToken() {
        val apiEndPoint = ApiClient.getClient(this)!!.create(ApiEndPoint::class.java)
        val call = apiEndPoint.getToken("csrf_token")
        call?.enqueue(object : Callback<CsrfTokenResponse> {
            override fun onFailure(call: Call<CsrfTokenResponse>, t: Throwable) {
                Toast.makeText(this@LoginActivity,"Error : $t", Toast.LENGTH_SHORT).show()
            }
            override fun onResponse(
                call: Call<CsrfTokenResponse>,
                response: Response<CsrfTokenResponse>
            ) {
                csrf_token = response.body()?.csrfToken
            }
        })
    }
    fun loginSubmit(userIn:String,passIn:String){
        PopupUtil.showLoading(this@LoginActivity,"Logging In","Please Wait")
        var intent = Intent(this,IndexActivity::class.java)
        val apiEndPoint = ApiClient.getClient(this)!!.create(ApiEndPoint::class.java)
        val call = apiEndPoint.loginChecklogin(
                userIn,
                passIn,
                "csrf_token")
        call?.enqueue(object : Callback<UserResponse>{
            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                PopupUtil.dismissDialog()
                Toasty.success(this@LoginActivity,"Login Error ",Toasty.LENGTH_SHORT).show()
            }

            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {

                var userResponse = response.body()
                if(userResponse!=null){
                    PopupUtil.dismissDialog()
                    if(userResponse.success!!){
                        if(userResponse.user!=null){
                            PrefsUtil.getInstance()
                                .setBooleanState(PrefsUtil.IS_LOGGED_IN,
                                    true)
                            PrefsUtil.getInstance()
                                .setStringState(PrefsUtil.USER_NAME,
                                    userResponse.user?.username)
                            PrefsUtil.getInstance()
                                .setStringState(PrefsUtil.DEPT,
                                    userResponse.user?.department)
                            PrefsUtil.getInstance()
                                .setStringState(PrefsUtil.SECTION,
                                    userResponse.user?.section)
                            PrefsUtil.getInstance()
                                .setStringState(PrefsUtil.RULE,
                                    userResponse.user?.section)
                            PrefsUtil.getInstance()
                                .setStringState(PrefsUtil.LEVEL,
                                    userResponse.user?.level)
                            Toasty.success(this@LoginActivity,"Login Success ",Toasty.LENGTH_LONG).show()
                            startActivity(intent)
                            finish()
                        }else{
                            Toasty.error(this@LoginActivity,"Username Or Password Wrong!",Toasty.LENGTH_SHORT).show()
                            clearForm()
                            InUsername.requestFocus()
                        }

                    }else{
                        Toasty.error(this@LoginActivity,"Username Or Password Wrong!",Toasty.LENGTH_SHORT).show()
                        clearForm()
                        InUsername.requestFocus()
                    }
                }else{
                    Toasty.error(this@LoginActivity,"Username Or Password Wrong!",Toasty.LENGTH_SHORT).show()
                    clearForm()
                    InUsername.requestFocus()
                }
            }

        })
    }
    private fun clearForm(){
        InUsername.text=null;
        InPassword.text=null;
    }
    private fun isValidatedAll()  :Boolean{

        clearError()
        if(InUsername.text!!.isEmpty()){
            tilUsername.error="Please Input Someting"
            InUsername.requestFocus()
            return false
        }
        if(InPassword.text!!.isEmpty()){
            tilPassword.error="Please Input Someting"
            InPassword.requestFocus()
            return false
        }
        PopupUtil.dismissDialog()
        return true
    }

    private fun clearError() {
        tilUsername.error=null
        tilPassword.error=null
    }
}
