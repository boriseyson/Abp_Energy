package com.misit.abpenergy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.misit.abpenergy.fragment.TotalRKbFragment
import com.misit.abpenergy.rkb.RkbActivity
import com.misit.abpenergy.utils.PrefsUtil
import es.dmoral.toasty.Toasty
import kotlinx.android.synthetic.main.activity_index.*
import kotlinx.android.synthetic.main.nav_header.*

class IndexActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener , View.OnClickListener {

    lateinit var toolbar: Toolbar
    lateinit var drawerLayout: DrawerLayout
    lateinit var navView: NavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_index)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.navigationView)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, 0, 0
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        logOut.setOnClickListener {
            drawer_layout.closeDrawer(GravityCompat.START)
            logOut()
        }
        navView.setNavigationItemSelectedListener(this)

        PrefsUtil.initInstance(this)
        if(PrefsUtil.getInstance().getBooleanState(PrefsUtil.IS_LOGGED_IN,true)){

            USERNAME = PrefsUtil.getInstance().getStringState(PrefsUtil.USER_NAME,"")
            DEPARTMENT = PrefsUtil.getInstance().getStringState(PrefsUtil.DEPT,"")
            SECTON = PrefsUtil.getInstance().getStringState(PrefsUtil.SECTION,"")
            LEVEL = PrefsUtil.getInstance().getStringState(PrefsUtil.LEVEL,"")
        }
        btnTotal.setOnClickListener(this@IndexActivity)
        btnApprove.setOnClickListener(this@IndexActivity)
        btnWaiting.setOnClickListener(this@IndexActivity)
        btnCancel.setOnClickListener(this@IndexActivity)
        btnSarpras.setOnClickListener(this@IndexActivity)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }
    private fun logOut() {
        AlertDialog.Builder(this)
            .setTitle("Confirmation")
            .setPositiveButton("OK , Sign Out",{
                    dialog,
                    which ->
                if(PrefsUtil.getInstance().getBooleanState(
                        PrefsUtil.IS_LOGGED_IN,true)){
                    PrefsUtil.getInstance().setBooleanState(
                        PrefsUtil.IS_LOGGED_IN,false)
                    PrefsUtil.getInstance().setStringState(
                        PrefsUtil.USER_NAME,null)
                    val intent = Intent(this,LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            })
            .setNegativeButton("Cancel",
                {
                        dialog,
                        which ->
                    dialog.dismiss()
                })
            .show()
    }
    companion object{
        var USERNAME = "username"
        var DEPARTMENT="department"
        var SECTON="section"
        var LEVEL="level"
        var Tab_INDEX ="tab_index"
    }

    override fun onClick(v: View?) {
        var intent = Intent(this@IndexActivity,RkbActivity::class.java)
        intent.putExtra(RkbActivity.Companion.USERNAME,USERNAME)
        intent.putExtra(RkbActivity.Companion.DEPARTMENT,DEPARTMENT)
        intent.putExtra(RkbActivity.Companion.SECTON,SECTON)
        intent.putExtra(RkbActivity.Companion.LEVEL,LEVEL)
        if(v?.id==R.id.btnTotal){
            var tbindex = 0 as Int
            intent.putExtra(RkbActivity.Companion.Tab_INDEX,tbindex)
            startActivity(intent)
        }
        if(v?.id==R.id.btnApprove){
            var tbindex = 1 as Int
            intent.putExtra(RkbActivity.Companion.Tab_INDEX,tbindex)
            startActivity(intent)
        }
        if(v?.id==R.id.btnWaiting){
            var tbindex = 2 as Int
            intent.putExtra(RkbActivity.Companion.Tab_INDEX,tbindex)
            startActivity(intent)
        }
        if(v?.id==R.id.btnCancel){
            var tbindex = 3 as Int
            intent.putExtra(RkbActivity.Companion.Tab_INDEX,tbindex)
            startActivity(intent)
        }
        if(v?.id==R.id.btnSarpras){
              intent = Intent(this@IndexActivity,SarprasActivity::class.java)
//            var tbindex = 3 as Int
//            intent.putExtra(RkbActivity.Companion.Tab_INDEX,tbindex)
            startActivity(intent)
        }
    }
}
