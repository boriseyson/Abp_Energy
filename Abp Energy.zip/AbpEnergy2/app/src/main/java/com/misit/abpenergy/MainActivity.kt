package com.misit.abpenergy

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AlertDialog
import com.bumptech.glide.Glide
import com.misit.abpenergy.utils.ConnectivityUtil
import com.misit.abpenergy.utils.PrefsUtil
import es.dmoral.toasty.Toasty
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       Glide.with(this).load(R.drawable.abp).into(imageView)

        PrefsUtil.initInstance(this)
        updateProgress()
    }
    fun updateProgress(){
        val runnable= {
            var besar = progressHorizontal.progress

            progressHorizontal.progress = besar + 10
            if (besar == 50) {
                if(cekKoneksi(this)){
                    updateProgress()
                }else {
                    koneksiInActive()
                }

            }else if(besar<100){
                updateProgress()
            } else {
                if(PrefsUtil.getInstance().getBooleanState(PrefsUtil.IS_LOGGED_IN,false))
                {
                    val intent = Intent(this, IndexActivity::class.java)
                    startActivity(intent)
                }
                else
                {
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                }
               finish()
            }
        }
        Handler().postDelayed(runnable,100)
    }
    fun cekKoneksi(context: Context):Boolean{
        var koneksiStatus : Boolean = true
        val connectivityManager= context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo

        return networkInfo != null && networkInfo.isConnected
    }
    fun koneksiInActive(){
        AlertDialog.Builder(this)
            .setTitle("Maaf Koneksi Internet Tidak Ada!")
            .setPositiveButton("OK, Keluar",{
                    dialog,
                    which ->
                finish()
            }).show()
    }
}
