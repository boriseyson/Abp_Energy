package com.misit.abpenergy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.manager.SupportRequestManagerFragment
import com.misit.abpenergy.fragment.ApproveRkbFragment
import com.misit.abpenergy.fragment.CancelFragment
import com.misit.abpenergy.fragment.WaitingRkbFragment
import com.misit.abpenergy.rkb.RkbActivity
import es.dmoral.toasty.Toasty
import java.util.*

class SarprasActivity : AppCompatActivity() {
    private var mSectionPagerAdapter : MyViewPagerAdapter? = null
    private var mViewPager : ViewPager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sarpras)



        mSectionPagerAdapter= MyViewPagerAdapter(supportFragmentManager)
        mViewPager = findViewById<View>(R.id.sarprasViewPager) as ViewPager
        mViewPager?.adapter = mSectionPagerAdapter
        mViewPager?.addOnPageChangeListener(object:ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) {

            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                if(position==0){
//                   var frag:Fragment =
                }
            }

        })
    }
    inner class MyViewPagerAdapter(fm: FragmentManager): FragmentStatePagerAdapter(fm){
        private val pages = listOf(
            ApproveRkbFragment(),
            WaitingRkbFragment(),
            CancelFragment()
        )
        override fun getItem(position: Int): Fragment {
            return pages[position]
        }

        override fun getCount(): Int {
            return pages.size
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return when(position){
                0 -> "First Tab"
                1 -> "Second Tab"
                else -> "Third Tab"
            }
        }

    }
}
