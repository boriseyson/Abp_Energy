package com.misit.abpenergy.rkb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.misit.abpenergy.IndexActivity
import com.misit.abpenergy.R
import com.misit.abpenergy.fragment.*
import es.dmoral.toasty.Toasty
import kotlinx.android.synthetic.main.activity_rkb.*
import kotlinx.coroutines.CancellationException

class RkbActivity : AppCompatActivity() {
//
    private var totalRKbFragment : TotalRKbFragment? = null
    private var approveRkbFragment : ApproveRkbFragment? = null
    private var waitingRkbFragment : WaitingRkbFragment? = null
    private var cancelFragment : CancelFragment? = null
    private  var tabIndex :Int?=null
    var username:String?=null
    var dept:String?=null
    var sect:String?=null
    var level:String?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rkb)
        //loadTotal()
        username = intent.getStringExtra(USERNAME)
        dept = intent.getStringExtra(DEPARTMENT)
        sect = intent.getStringExtra(SECTON)
        level = intent.getStringExtra(LEVEL)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        tabIndex=intent.getIntExtra(Tab_INDEX,0)
        if(tabIndex==0){
            loadTotal()
        }else if(tabIndex==1){
            loadApprove()
        }else if(tabIndex==2){
            loadWaiting()
        }else if(tabIndex==3){
            loadCancel()
        }else{
            Toasty.error(this,"NO INDEX",Toasty.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId==R.id.Home){
//            Toasty.error(this,"NO INDEX",Toasty.LENGTH_SHORT).show()
            //onBackPressed()
            finish()
        }
        return super.onOptionsItemSelected(item)
    }
    fun loadTotal(){
        totalRKbFragment = TotalRKbFragment()
        val argument = Bundle()
        argument.putString(USERNAME,username)
        argument.putString(DEPARTMENT,dept)
        argument.putString(SECTON,sect)
        argument.putString(LEVEL,level)
        totalRKbFragment?.arguments = argument
        supportFragmentManager.beginTransaction().replace(R.id.container,totalRKbFragment!!)
            .commit()
    }
    fun loadApprove(){
        approveRkbFragment = ApproveRkbFragment()
        val argument = Bundle()
        argument.putString(USERNAME,username)
        argument.putString(DEPARTMENT,dept)
        argument.putString(SECTON,sect)
        argument.putString(LEVEL,level)
        approveRkbFragment?.arguments=argument
        supportFragmentManager.beginTransaction().replace(R.id.container,approveRkbFragment!!)
            .commit()
    }
    fun loadWaiting(){
        waitingRkbFragment = WaitingRkbFragment()
        val argument = Bundle()
        argument.putString(USERNAME,username)
        argument.putString(DEPARTMENT,dept)
        argument.putString(SECTON,sect)
        argument.putString(LEVEL,level)
        waitingRkbFragment?.arguments=argument
        supportFragmentManager.beginTransaction().replace(R.id.container,waitingRkbFragment!!)
            .commit()
    }
    fun loadCancel(){

        cancelFragment = CancelFragment()
        val argument = Bundle()
        argument.putString(USERNAME,username)
        argument.putString(DEPARTMENT,dept)
        argument.putString(SECTON,sect)
        argument.putString(LEVEL,level)
        cancelFragment?.arguments=argument
        supportFragmentManager.beginTransaction().replace(R.id.container,cancelFragment!!)
            .commit()
    }

    companion object{
        var Tab_INDEX = "tab_index"
        var USERNAME = "username"
        var DEPARTMENT="department"
        var SECTON="section"
        var LEVEL="level"
    }
}
